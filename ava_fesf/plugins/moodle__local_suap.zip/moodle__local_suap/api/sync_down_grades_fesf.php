<?php
namespace local_suap;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('../../../config.php');
require_once("../locallib.php");
require_once("servicelib.php");

// Link de acesso (exemplo): http://localhost/moodle/local/suap/api/?sync_down_grades_fesf&nome_breve_curso_moodle=EATIC - AJ

class sync_down_grades_fesf_service extends service {

    function get_notas($shortname) {

        return \local_suap\get_recordset_as_array("
            select   gi.itemname descricao_nota, u.username matricula_aluno, gg.finalgrade nota_aluno, c.shortname
                from     mdl_grade_grades gg
                            inner join mdl_grade_items gi on (gg.itemid=gi.id)
                            inner join mdl_course c on (gi.courseid = c.id)
                            inner join mdl_user u on (gg.userid=u.id)
                where gg.finalgrade is not null
                and    c.shortname = ?
        
        ",
            [$shortname]);
    }
    
    function do_call() {
        global $CFG, $DB;
        try {
            return $this->get_notas(
                \local_suap\aget($_GET, 'nome_breve_curso_moodle', null),
            );

        } catch (Exception $ex) {
            die("error");
            http_response_code(500);
            if ($ex->getMessage() == "Data submitted is invalid (value: Data submitted is invalid)") {
                echo json_encode(["error" => ["message" => "Ocorreu uma inconsistência no servidor do AVA. Este erro é conhecido e a solução dele já está sendo estudado pela equipe de desenvolvimento. Favor tentar novamente em 5 minutos."]]);
            } else {
                echo json_encode(["error" => ["message" => $ex->getMessage()]]);
            }
        }
    }

}