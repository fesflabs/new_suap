<?php

namespace local_suap;

require_once('../../../config.php');
require_once('../locallib.php');
require_once("servicelib.php");


class get_curso_service extends \local_suap\service {

    function get_curso_by_shortname($shortname) {

        return \local_suap\get_recordset_as_array("
                SELECT c.id ,
                   c.fullname,
                   c.shortname 
                FROM {course} c            
                WHERE c.shortname = ?
            ",
            [$shortname]);
    }

    function get_curso($shortname) {
        global $DB, $CFG, $USER;
        $prefix = $CFG->wwwroot.'/course/view.php';
//        error_log(print_r($prefix,true));
        $curso_moodle = $this->get_curso_by_shortname($shortname);
        if (count($curso_moodle)>0){
            return ["url" => "$prefix?id={$curso_moodle[0] ->id}"];
        }else{
            throw new \Exception("Curso não encontrado.", 404);
        }
    }

    function do_call() {
//        error_log(print_r('Call curso',true));
        return $this->get_curso(
            \local_suap\aget($_GET, 'curso', null),

        );
    }
}