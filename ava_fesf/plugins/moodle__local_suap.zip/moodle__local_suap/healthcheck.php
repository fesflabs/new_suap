<?php
require_once("../../config.php");
echo "<pre>PHP: OK.\n
Configuração do Moodle: OK.\n
Conexão com o banco: OK.\n
Rota no .htaccess: OK.\n
Tudo bem até aqui:" . " sim.\n";
